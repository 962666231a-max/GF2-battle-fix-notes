# GF2（少女前线2：追放）PC 端 支付 SDK 破解记录

## 核心结论（从反汇编得到，不是猜）
MTSDKApi.HttpClient.CreateOrderByQR 的成功回调要求响应的 **data 里同时有 limit / param / order_id**：

`csharp
var inner = data["data"];              // get_Item，缺 key 直接抛 KeyNotFoundException
var limit    = inner["limit"];         // 必须存在（对象 → 走限流回调，失败）
var param    = inner["param"];         // 字符串 = 二维码内容
var order_id = inner["order_id"];      // 字符串 = 订单号
if (param/order_id 是字符串) onCreateQROrderSucc(param, order_id);
`

RequestQROrderState（order/qr_confirm）的成功条件：

`csharp
var d = data["data"];
if ((int)d == 1) onOrderPaySuccess.Invoke();
`

### 服务端实现
`
POST /alipay/create_order_qr → {"code":0,"msg":"ok","data":{"limit":0,"param":"<qr url>","order_id":"<id>"}}
POST /order/qr_confirm       → {"code":0,"msg":"ok","data":1}
`
实测：客户端弹出二维码 → 弹"成功购买" → 服务端按 StoreGoodData.reward 发货进账号。

## 文件说明
| 文件 | 说明 |
|---|---|
| global-metadata.dec.dat | **解密后的 il2cpp 全局元数据**（17.1MB）。磁盘上的 global-metadata.dat 是加密的，这份是从进程内存按区域 VA=0x2A60DCF9000（17,924,096 字节）抠出来的 |
| dump.cs | Il2CppDumper v6.7.46 用上述元数据 + GameAssembly.dll 解析的结果（版本实测 **24.4**） |
| stringliteral.json | 代码引用的字面量 + 地址（用于反汇编时把 rip 寻址还原成字符串） |

## 复现步骤
1. 用 Il2CppDumper：Il2CppDumper.exe GameAssembly.dll global-metadata.dec.dat out/
   - 注意：元数据版本字段被改过，需把第 4 字节写成 24 才能解析（这是加密/混淆痕迹）
2. dump.cs 里搜 CreateOrderByQR / RequestQROrderState，取 RVA
3. 用 capstone 反汇编该方法（GameAssembly.dll，ImageBase 0x180000000），
   把 [rip+disp] 算成绝对地址，去 stringliteral.json 里查对应字符串
   → 就能读出它读了哪些 JSON 字段

## 已知遗留
- 商城界面在购买成功后**不会当场刷新**成"已拥有"，客户端重新进入商店页才会重拉数据（服务端数据是对的）
